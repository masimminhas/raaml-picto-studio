RAAML Picto Studio - Example Models
===================================

Contents
--------
  raaml-picto-studio/   AEB and GIP case studies, Picto view templates,
                        the EVL catalogue, and the round-trip ETL programs.
  edu.kit.sdq.raaml/    The RAAML Ecore metamodel and the Refinery/EVL
                        validation pilot.

Prerequisites
-------------
  Eclipse (Modeling package or any Eclipse with EMF)
  Epsilon 2.8
  RAAML Picto Studio, from
    https://masimminhas.github.io/raaml-picto-studio/

Import
------
  File > Import > General > Existing Projects into Workspace
    > Select archive file > this zip
  Import BOTH projects. The .picto views resolve their metamodel through
  platform:/resource/edu.kit.sdq.raaml/model/raaml.ecore, so importing only
  raaml-picto-studio leaves every view unable to load its metamodel.

Viewing a model
---------------
  Window > Show View > Other > Epsilon > Picto
  Then click any .picto file. Suggested starting points:

    aeb_fmea.picto                     risk-coloured FMEA table
    aeb_fta.picto                      IEC 61025 fault tree
    aeb_stpa_controlstructure.picto    STPA control structure
    aeb_gsn.picto                      GSN argument structure
    samples-infusion-pump/
      gip_stpa_controlstructure.picto  the medical-device case study

  In the AEB control structure, CA-01 is drawn emphasised with a UCA badge
  while CA-02 and CA-03 are muted: six of the seven AEB unsafe control
  actions name their control action only in prose and never populate the
  reference. The GIP model shows the opposite, with every control action
  covered.

Running the validation
----------------------
  Right-click validate-all.xml > Run As > Ant Build...
    JRE tab > "Run in the same JRE as the workspace" > Run

  Expected on the AEB models:  FTA 1, STPA 6, all others 0  (7 findings)
  Expected on the GIP models:  0 findings
    (validate-all-infusion-pump.xml)

Round-trip transformations
--------------------------
  In transformations/, right-click a run-*.xml > Run As > Ant Build...
    JRE tab > "Run in the same JRE as the workspace" > Run

  Forward (OMG RAAML profile UML -> Ecore), each with its source committed:
    run-pair1-fmea.xml      RaamlProfile/FMEALibrary.uml
    run-pair1-fta.xml       RaamlProfile/FTALibrary.uml
    run-pair2-fmea.xml      samples/aeb_fmea_usermodel.uml
    run-pair2-hara.xml      samples/aeb_hara_usermodel.uml
    run-pair2-req.xml       samples/aeb_req_usermodel.uml
    run-pair2-stpa.xml      samples/aeb_stpa_usermodel.uml
    run-pair2-fta.xml       samples/fta_usermodel.uml

  Backward (Ecore -> UML with provenance annotations): the matching
  run-*-backward.xml for each of the above.

  Two ordering notes:
    run-pair1-fta-backward.xml consumes FTALibrary.raaml.xmi, which
    run-pair1-fta.xml produces. Run the forward one first.

    run-pair2-gsn.xml reads aeb_gsn_usermodel_roundtrip.uml, the output of
    run-pair2-gsn-backward.xml, because the hand-authored Papyrus source
    for GSN was never committed. Run the backward one first. That pair
    therefore shows round-trip closure rather than starting from an
    externally authored profile model.

Opening the .uml source models (optional)
-----------------------------------------
  The profile models under transformations/samples/ apply both the OMG
  RAAML profile and SysML 1.6. Opening one in the UML editor therefore
  needs Papyrus with SysML 1.6 installed; without it Eclipse reports
    MalformedURLException: unknown protocol: pathmap
  for pathmap://SysML16_PROFILES/... That is a missing Eclipse feature on
  the viewer's side, not a defect in the models.

  You do NOT need Papyrus to run the transformations. The ETL programs
  detect stereotype applications by inspecting the loaded XMI directly
  rather than resolving the profile, which is what lets them run under
  plain Ant outside a configured Eclipse. Running run-pair2-fmea.xml in an
  Eclipse with no Papyrus installed exercises exactly that property.

Note on project natures
-----------------------
  Both projects are plain resource projects with no PDE plugin nature.
  This is deliberate: the installed plugin registers raaml-picto-studio as
  a singleton bundle, and a workspace project declaring the same symbolic
  name would make Eclipse refuse to resolve either, reporting "Unable to
  resolve plug-in raaml-picto-studio".

  The full source, including the plugin projects, is at
    https://github.com/masimminhas/raaml-picto-studio

Licence
-------
  EPL-2.0
